#include<iostream>
using namespace std;
int main()
{
    int n,facto=1;
    cin>>n;
for(int i=1;i<=n;i++){
     facto=facto*i;
     
}
cout<<facto;
   return 0;
}