#include<iostream>
using namespace std;
int main()
{
    int a=7;
    for(int i=1;i<=10;i++){
        int table=a*i;
        cout<<table<<endl;
    }
   return 0;
}