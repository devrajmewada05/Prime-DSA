#include<iostream>
using namespace std;
int main()
{
    int A,B;
    cin>>A;
    cin>>B;
    if(A>B){
        cout<<"A is greater";
    }
    else {
        cout<<"B is greater";
    }
   return 0;
}